const db = require('../db');

const getAllAlbums = (req, res) => {
  const sql = `
    SELECT albums.*, artists.name AS artist_name
    FROM albums
    JOIN artists ON albums.artist_id = artists.id
    ORDER BY albums.id ASC
  `;

  db.all(sql, [], (err, rows) => {
    if (err) {
      return res.status(500).json({ message: 'Failed to fetch albums', error: err.message });
    }
    res.status(200).json({ message: 'Albums fetched successfully', data: rows });
  });
};

const getAlbumById = (req, res) => {
  const { id } = req.params;

  const sql = `
    SELECT albums.*, artists.name AS artist_name
    FROM albums
    JOIN artists ON albums.artist_id = artists.id
    WHERE albums.id = ?
  `;

  db.get(sql, [id], (err, row) => {
    if (err) {
      return res.status(500).json({ message: 'Failed to fetch album', error: err.message });
    }
    if (!row) {
      return res.status(404).json({ message: 'Album not found' });
    }
    res.status(200).json({ message: 'Album fetched successfully', data: row });
  });
};

const createAlbum = (req, res) => {
  const { name, release_year, number_of_listens, artist_id } = req.body;

  if (!name || release_year === undefined || number_of_listens === undefined || !artist_id) {
    return res.status(400).json({ message: 'name, release_year, number_of_listens, and artist_id are required' });
  }

  db.get('SELECT * FROM artists WHERE id = ?', [artist_id], (artistErr, artist) => {
    if (artistErr) {
      return res.status(500).json({ message: 'Failed to validate artist', error: artistErr.message });
    }
    if (!artist) {
      return res.status(400).json({ message: 'artist_id does not reference a valid artist' });
    }

    const sql = 'INSERT INTO albums (name, release_year, number_of_listens, artist_id) VALUES (?, ?, ?, ?)';
    db.run(sql, [name, release_year, number_of_listens, artist_id], function (err) {
      if (err) {
        return res.status(500).json({ message: 'Failed to create album', error: err.message });
      }

      db.get('SELECT * FROM albums WHERE id = ?', [this.lastID], (fetchErr, row) => {
        if (fetchErr) {
          return res.status(500).json({ message: 'Album created but failed to fetch it', error: fetchErr.message });
        }
        res.status(201).json({ message: 'Album created successfully', data: row });
      });
    });
  });
};

const updateAlbum = (req, res) => {
  const { id } = req.params;
  const { name, release_year, number_of_listens, artist_id } = req.body;

  db.get('SELECT * FROM albums WHERE id = ?', [id], (checkErr, existing) => {
    if (checkErr) {
      return res.status(500).json({ message: 'Failed to check album', error: checkErr.message });
    }
    if (!existing) {
      return res.status(404).json({ message: 'Album not found' });
    }

    const finalizeUpdate = (validatedArtistId) => {
      const updatedName = name ?? existing.name;
      const updatedYear = release_year ?? existing.release_year;
      const updatedListens = number_of_listens ?? existing.number_of_listens;
      const updatedArtistId = validatedArtistId ?? existing.artist_id;

      const sql = 'UPDATE albums SET name = ?, release_year = ?, number_of_listens = ?, artist_id = ? WHERE id = ?';
      db.run(sql, [updatedName, updatedYear, updatedListens, updatedArtistId, id], function (err) {
        if (err) {
          return res.status(500).json({ message: 'Failed to update album', error: err.message });
        }

        db.get('SELECT * FROM albums WHERE id = ?', [id], (fetchErr, row) => {
          if (fetchErr) {
            return res.status(500).json({ message: 'Album updated but failed to fetch it', error: fetchErr.message });
          }
          res.status(200).json({ message: 'Album updated successfully', data: row });
        });
      });
    };

    if (artist_id !== undefined) {
      db.get('SELECT * FROM artists WHERE id = ?', [artist_id], (artistErr, artist) => {
        if (artistErr) {
          return res.status(500).json({ message: 'Failed to validate artist', error: artistErr.message });
        }
        if (!artist) {
          return res.status(400).json({ message: 'artist_id does not reference a valid artist' });
        }
        finalizeUpdate(artist_id);
      });
    } else {
      finalizeUpdate();
    }
  });
};

const deleteAlbum = (req, res) => {
  const { id } = req.params;

  db.get('SELECT * FROM albums WHERE id = ?', [id], (checkErr, existing) => {
    if (checkErr) {
      return res.status(500).json({ message: 'Failed to check album', error: checkErr.message });
    }
    if (!existing) {
      return res.status(404).json({ message: 'Album not found' });
    }

    db.run('DELETE FROM albums WHERE id = ?', [id], function (err) {
      if (err) {
        return res.status(500).json({ message: 'Failed to delete album', error: err.message });
      }
      res.status(200).json({ message: 'Album deleted successfully', deletedId: Number(id) });
    });
  });
};

module.exports = {
  getAllAlbums,
  getAlbumById,
  createAlbum,
  updateAlbum,
  deleteAlbum
};