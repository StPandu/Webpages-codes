const db = require('../db');

const getAllArtists = (req, res) => {
  db.all('SELECT * FROM artists ORDER BY id ASC', [], (err, rows) => {
    if (err) {
      return res.status(500).json({ message: 'Failed to fetch artists', error: err.message });
    }
    res.status(200).json({ message: 'Artists fetched successfully', data: rows });
  });
};

const getArtistById = (req, res) => {
  const { id } = req.params;

  db.get('SELECT * FROM artists WHERE id = ?', [id], (err, row) => {
    if (err) {
      return res.status(500).json({ message: 'Failed to fetch artist', error: err.message });
    }
    if (!row) {
      return res.status(404).json({ message: 'Artist not found' });
    }
    res.status(200).json({ message: 'Artist fetched successfully', data: row });
  });
};

const createArtist = (req, res) => {
  const { name, genre, monthly_listeners } = req.body;

  if (!name || !genre || monthly_listeners === undefined) {
    return res.status(400).json({ message: 'name, genre, and monthly_listeners are required' });
  }

  const sql = 'INSERT INTO artists (name, genre, monthly_listeners) VALUES (?, ?, ?)';
  db.run(sql, [name, genre, monthly_listeners], function (err) {
    if (err) {
      return res.status(500).json({ message: 'Failed to create artist', error: err.message });
    }

    db.get('SELECT * FROM artists WHERE id = ?', [this.lastID], (fetchErr, row) => {
      if (fetchErr) {
        return res.status(500).json({ message: 'Artist created but failed to fetch it', error: fetchErr.message });
      }
      res.status(201).json({ message: 'Artist created successfully', data: row });
    });
  });
};

const updateArtist = (req, res) => {
  const { id } = req.params;
  const { name, genre, monthly_listeners } = req.body;

  db.get('SELECT * FROM artists WHERE id = ?', [id], (checkErr, existing) => {
    if (checkErr) {
      return res.status(500).json({ message: 'Failed to check artist', error: checkErr.message });
    }
    if (!existing) {
      return res.status(404).json({ message: 'Artist not found' });
    }

    const updatedName = name ?? existing.name;
    const updatedGenre = genre ?? existing.genre;
    const updatedListeners = monthly_listeners ?? existing.monthly_listeners;

    const sql = 'UPDATE artists SET name = ?, genre = ?, monthly_listeners = ? WHERE id = ?';
    db.run(sql, [updatedName, updatedGenre, updatedListeners, id], function (err) {
      if (err) {
        return res.status(500).json({ message: 'Failed to update artist', error: err.message });
      }

      db.get('SELECT * FROM artists WHERE id = ?', [id], (fetchErr, row) => {
        if (fetchErr) {
          return res.status(500).json({ message: 'Artist updated but failed to fetch it', error: fetchErr.message });
        }
        res.status(200).json({ message: 'Artist updated successfully', data: row });
      });
    });
  });
};

const deleteArtist = (req, res) => {
  const { id } = req.params;

  db.get('SELECT * FROM artists WHERE id = ?', [id], (checkErr, existing) => {
    if (checkErr) {
      return res.status(500).json({ message: 'Failed to check artist', error: checkErr.message });
    }
    if (!existing) {
      return res.status(404).json({ message: 'Artist not found' });
    }

    db.run('DELETE FROM artists WHERE id = ?', [id], function (err) {
      if (err) {
        return res.status(500).json({ message: 'Failed to delete artist', error: err.message });
      }
      res.status(200).json({ message: 'Artist deleted successfully', deletedId: Number(id) });
    });
  });
};

module.exports = {
  getAllArtists,
  getArtistById,
  createArtist,
  updateArtist,
  deleteArtist
};