const db = require('../db');

const getAllSongs = (req, res) => {
  const sql = `
    SELECT songs.*, albums.name AS album_name
    FROM songs
    JOIN albums ON songs.album_id = albums.id
    ORDER BY songs.id ASC
  `;

  db.all(sql, [], (err, rows) => {
    if (err) {
      return res.status(500).json({ message: 'Failed to fetch songs', error: err.message });
    }
    res.status(200).json({ message: 'Songs fetched successfully', data: rows });
  });
};

const getSongById = (req, res) => {
  const { id } = req.params;

  const sql = `
    SELECT songs.*, albums.name AS album_name
    FROM songs
    JOIN albums ON songs.album_id = albums.id
    WHERE songs.id = ?
  `;

  db.get(sql, [id], (err, row) => {
    if (err) {
      return res.status(500).json({ message: 'Failed to fetch song', error: err.message });
    }
    if (!row) {
      return res.status(404).json({ message: 'Song not found' });
    }
    res.status(200).json({ message: 'Song fetched successfully', data: row });
  });
};

const createSong = (req, res) => {
  const { name, release_year, album_id } = req.body;

  if (!name || release_year === undefined || !album_id) {
    return res.status(400).json({ message: 'name, release_year, and album_id are required' });
  }

  db.get('SELECT * FROM albums WHERE id = ?', [album_id], (albumErr, album) => {
    if (albumErr) {
      return res.status(500).json({ message: 'Failed to validate album', error: albumErr.message });
    }
    if (!album) {
      return res.status(400).json({ message: 'album_id does not reference a valid album' });
    }

    const sql = 'INSERT INTO songs (name, release_year, album_id) VALUES (?, ?, ?)';
    db.run(sql, [name, release_year, album_id], function (err) {
      if (err) {
        return res.status(500).json({ message: 'Failed to create song', error: err.message });
      }

      db.get('SELECT * FROM songs WHERE id = ?', [this.lastID], (fetchErr, row) => {
        if (fetchErr) {
          return res.status(500).json({ message: 'Song created but failed to fetch it', error: fetchErr.message });
        }
        res.status(201).json({ message: 'Song created successfully', data: row });
      });
    });
  });
};

const updateSong = (req, res) => {
  const { id } = req.params;
  const { name, release_year, album_id } = req.body;

  db.get('SELECT * FROM songs WHERE id = ?', [id], (checkErr, existing) => {
    if (checkErr) {
      return res.status(500).json({ message: 'Failed to check song', error: checkErr.message });
    }
    if (!existing) {
      return res.status(404).json({ message: 'Song not found' });
    }

    const finalizeUpdate = (validatedAlbumId) => {
      const updatedName = name ?? existing.name;
      const updatedYear = release_year ?? existing.release_year;
      const updatedAlbumId = validatedAlbumId ?? existing.album_id;

      const sql = 'UPDATE songs SET name = ?, release_year = ?, album_id = ? WHERE id = ?';
      db.run(sql, [updatedName, updatedYear, updatedAlbumId, id], function (err) {
        if (err) {
          return res.status(500).json({ message: 'Failed to update song', error: err.message });
        }

        db.get('SELECT * FROM songs WHERE id = ?', [id], (fetchErr, row) => {
          if (fetchErr) {
            return res.status(500).json({ message: 'Song updated but failed to fetch it', error: fetchErr.message });
          }
          res.status(200).json({ message: 'Song updated successfully', data: row });
        });
      });
    };

    if (album_id !== undefined) {
      db.get('SELECT * FROM albums WHERE id = ?', [album_id], (albumErr, album) => {
        if (albumErr) {
          return res.status(500).json({ message: 'Failed to validate album', error: albumErr.message });
        }
        if (!album) {
          return res.status(400).json({ message: 'album_id does not reference a valid album' });
        }
        finalizeUpdate(album_id);
      });
    } else {
      finalizeUpdate();
    }
  });
};

const deleteSong = (req, res) => {
  const { id } = req.params;

  db.get('SELECT * FROM songs WHERE id = ?', [id], (checkErr, existing) => {
    if (checkErr) {
      return res.status(500).json({ message: 'Failed to check song', error: checkErr.message });
    }
    if (!existing) {
      return res.status(404).json({ message: 'Song not found' });
    }

    db.run('DELETE FROM songs WHERE id = ?', [id], function (err) {
      if (err) {
        return res.status(500).json({ message: 'Failed to delete song', error: err.message });
      }
      res.status(200).json({ message: 'Song deleted successfully', deletedId: Number(id) });
    });
  });
};

module.exports = {
  getAllSongs,
  getSongById,
  createSong,
  updateSong,
  deleteSong
};