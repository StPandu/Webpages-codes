const express = require('express');
const controller = require('../controllers/albumsController');

const router = express.Router();

router.get('/', controller.getAllAlbums);
router.get('/:id', controller.getAlbumById);
router.post('/', controller.createAlbum);
router.put('/:id', controller.updateAlbum);
router.patch('/:id', controller.updateAlbum);
router.delete('/:id', controller.deleteAlbum);

module.exports = router;